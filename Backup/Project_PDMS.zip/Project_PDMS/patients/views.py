import csv
import logging
import openpyxl
from datetime import datetime, date
from dateutil import parser
from django.shortcuts import render, redirect
from django.http import HttpResponse
from django.contrib import messages
from django.contrib.auth.decorators import login_required
from django.contrib.auth import login
from django.contrib.auth.views import LoginView, LogoutView
from django.core.paginator import Paginator
from .models import ECHS, CGHS, CAPF
from .utils import get_panel_model, get_expected_headers, map_common_fields, get_searchable_fields

logger = logging.getLogger(__name__)

class CustomLoginView(LoginView):
    template_name = "patients/login.html"

    def form_valid(self, form):
        user = form.get_user()
        login(self.request, user)
        logger.info(f"User {user} logged in successfully.")
        return redirect("patients:home")

    def form_invalid(self, form):
        logger.warning("Login failed: Invalid credentials.")
        return super().form_invalid(form)

class CustomLogoutView(LogoutView):
    next_page = "patients:login"

@login_required
def home(request):
    try:
        echs_count = ECHS.objects.count()
        cghs_count = CGHS.objects.count()
        capf_count = CAPF.objects.count()
    except Exception as e:
        logger.error(f"Error fetching dashboard data: {e}")
        return HttpResponse(f"Error querying database: {e}")

    return render(request, "patients/home.html", {
        "echs_count": echs_count,
        "cghs_count": cghs_count,
        "capf_count": capf_count,
    })

@login_required
def panel_dashboard(request, panel_name):
    model, panel_title = get_panel_model(panel_name)
    if not model:
        messages.error(request, "Invalid panel selected.")
        return redirect("patients:home")

    return render(request, "patients/panel_dashboard.html", {
        "panel_name": panel_name,
        "panel_title": panel_title,
    })

@login_required
def upload_data(request, panel_name):
    model, panel_title = get_panel_model(panel_name)
    if not model:
        messages.error(request, "Invalid panel.")
        return redirect("patients:home")

    if request.method == "POST":
        excel_file = request.FILES.get("file")

        if not excel_file or not excel_file.name.endswith(".xlsx"):
            messages.error(request, "Please upload a valid .xlsx file.")
            return redirect("patients:upload_data", panel_name=panel_name)

        try:
            wb = openpyxl.load_workbook(excel_file, data_only=True)
            sheet = wb.active
            expected_headers = get_expected_headers(panel_name)
            uploaded_headers = [cell.value for cell in sheet[1]]

            if not set(expected_headers).issubset(set(uploaded_headers)):
                missing_headers = set(expected_headers) - set(uploaded_headers)
                messages.error(request, f"Missing required headers: {', '.join(missing_headers)}")
                return redirect("patients:upload_data", panel_name=panel_name)

            column_indices = [uploaded_headers.index(header) for header in expected_headers]
            success_count, duplicate_count = 0, 0

            for row in sheet.iter_rows(min_row=2, values_only=True):
                row_data = {expected_headers[i]: row[column_indices[i]] for i in range(len(column_indices))}

                for key, value in row_data.items():
                    if "date" in key and isinstance(value, str):
                        try:
                            row_data[key] = parser.parse(value).strftime("%Y-%m-%d")
                        except ValueError:
                            row_data[key] = None  

                filters = {key: row_data[key] for key in expected_headers if row_data[key] is not None}
                existing_entry = model.objects.filter(**filters).exists()

                if not existing_entry:
                    try:
                        model.objects.create(**row_data)
                        success_count += 1
                    except Exception as e:
                        logger.error(f"[UPLOAD] Error inserting row: {e}")
                        messages.error(request, f"Error inserting row: {e}")
                else:
                    duplicate_count += 1

            messages.success(request, f"{success_count} rows uploaded successfully! {duplicate_count} duplicates were skipped.")

            return redirect("patients:upload_data", panel_name=panel_name)

        except Exception as e:
            logger.error(f"[UPLOAD] Panel: {panel_name}, Error: {e}")
            messages.error(request, f"Error during upload: {e}")

    return render(request, "patients/upload.html", {"panel_name": panel_name})

@login_required
def search_patient(request, panel_name):
    model, panel_title = get_panel_model(panel_name)
    if not model:
        messages.error(request, "Invalid panel selected.")
        return redirect("patients:home")

    query = request.GET.get("q", "").strip()
    search_by = request.GET.get("search_by", "card_number")
    selected_columns = request.GET.getlist("columns", [])

    filters = {f"{search_by}__icontains": query} if query else {}
    results = model.objects.filter(**filters) if query else None

    paginator = Paginator(results, 20) if results else None
    page = request.GET.get("page")
    paginated_results = paginator.get_page(page) if paginator else None

    fields = [field for field in model._meta.fields if field.name not in ["id"]]
    date_fields = {"admit_date", "admission_date"}
    visible_fields = selected_columns if selected_columns else [field.name for field in fields]

    return render(request, "patients/search.html", {
        "panel_name": panel_name,
        "panel_title": panel_title,
        "results": paginated_results,
        "query": query,
        "search_by": search_by,
        "fields": fields,
        "date_fields": date_fields,
        "visible_fields": visible_fields,
        "search_fields": get_searchable_fields(panel_name),
    })

@login_required
def download_sample_format(request, panel_name):
    model, panel_title = get_panel_model(panel_name)
    if not model:
        messages.error(request, "Invalid panel.")
        return redirect("patients:home")

    response = HttpResponse(content_type="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet")
    response["Content-Disposition"] = f'attachment; filename="{panel_name}_sample_format.xlsx"'

    wb = openpyxl.Workbook()
    ws = wb.active
    ws.title = f"{panel_title} Sample Data"
    ws.append(get_expected_headers(panel_name))

    wb.save(response)
    return response

@login_required
def export_search_results(request, panel_name):
    model, panel_title = get_panel_model(panel_name)
    if not model:
        messages.error(request, "Invalid panel.")
        return redirect("patients:home")

    query = request.GET.get("q", "").strip()
    search_by = request.GET.get("search_by", "card_number")
    selected_columns = request.GET.getlist("columns", [])

    if not query:
        messages.warning(request, "No search query provided for export.")
        return redirect("patients:search_patient", panel_name=panel_name)

    results = model.objects.filter(**{search_by + "__icontains": query})

    date_fields = {"admit_date", "admission_date"}

    if not results.exists():
        messages.warning(request, "No matching records found for export.")
        return redirect("patients:search_patient", panel_name=panel_name)

    response = HttpResponse(content_type="text/csv")
    response["Content-Disposition"] = f'attachment; filename="search_results_{panel_name}.csv"'

    writer = csv.writer(response)
    headers = [field.verbose_name.title() for field in model._meta.fields if field.name in selected_columns]
    writer.writerow(headers)

    for result in results:
        row = []
        for field in model._meta.fields:
            if field.name not in selected_columns:
                continue
            value = getattr(result, field.name)
            if field.name in date_fields and isinstance(value, (datetime, date)):
                value = value.strftime("%d-%b-%y")
            row.append(value if value else "")
        writer.writerow(row)

    return response
